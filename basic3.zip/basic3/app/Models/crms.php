<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Support\Facades\DB;

class crms extends Model
{
    use HasFactory;
    protected $table = 'crms';
    protected $fillable = [
        'id',
        'crm_name',
        'username',
        'password',
        'url',
        'status',
        'user_id'
    
    ];

    public function getAllthelistedCRM($adminId){
        $query = "SELECT * FROM `crms` where `user_id`=".$adminId." ORDER by `id` ASC";
       

        $results = DB::select($query);

        return $results;
    }
}
