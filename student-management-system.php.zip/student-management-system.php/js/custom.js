// jQuery(document).ready(function() {
//   $('#employeeTable').DataTable();
// });
jQuery(document).ready(function() {
  jQuery("#upload_profile_btn").click(function(event) {
      event.preventDefault(); // 'preventDefault' should be camelCase

      let mediauploader = wp.media({ // 'wp.media' should be followed by parentheses
          title: "Select profile image", // Object properties should be separated by commas, not semicolons
          multiple: false
      });

      mediauploader.on('select', function() {
          let attachment = mediauploader.state().get('selection').first().toJSON();
          console.log(attachment);
      });

      mediauploader.open();
  });

  jQuery('#employeeTable').DataTable(); // Initialize DataTables

  jQuery("#sms-add-student").validate({
    rules: {
      name: {
        required: true,
        minlength: 2
      },
      email: {
        required: true,
        email: true
      },
      address: {
        required: true,
        minlength: 2
      },
              phone: {
        required: true,
        minlength: 10
      },
      designation: {
        required: true,
        minlength: 2
      },
              gender: "required",
    },
    messages: {
      name: {
        required: "Please enter a name",
        minlength: "please enter a valid name"
      },
      email: "Please enter a valid email address",
              
              phone: {
        required: "Please enter  phone number",
        minlength: "please enter a valid phone number"
      },
              
      gender: "Please select gender"
    }
  });
  });
 

