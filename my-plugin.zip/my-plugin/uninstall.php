<?php
if (!defined( 'WP_UNINSTALL_PLUGIN' ) ) {
    die("Unauthorized access");
}
// Include WordPress database access
include_once(ABSPATH . 'wp-admin/includes/upgrade.php');

global $wpdb, $table_prefix;
$table = $table_prefix . "employee";
$sql_query = "DROP TABLE IF EXISTS `$table`";
$wpdb->query($sql_query);