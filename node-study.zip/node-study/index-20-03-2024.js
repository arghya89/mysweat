const express = require ('express');
const path = require ('path');
const mongoose = require('mongoose');

const app = express();
mongoose.connect("mongodb+srv://arghyammukherjee:arghyammukherjee@leaning-purpose.qdaigp8.mongodb.net/?retryWrites=true&w=majority&appName=leaning-purpose");
const user = require('./model');
const publicpath = path.join(__dirname,'public');
console.log(publicpath);
const reqfilter = require('./middleware');
app.use(reqfilter);
//same page middleware code
// const reqfilter = (req,resp,next)=>{
//     if(!req.query.age){
//         resp.send('Please provide your age to access  page')
//     }
//     else if(req.query.age < 18){
//     resp.send('Not eligibale to access  page')
//     }
//     else{
//         next();
//     }
// }
// app.use(reqfilter);



//app.use(express.static(publicpath));// if you want to remove the extension then you cant use this code
//required code is below

app.set('view engine','ejs');
app.get('',reqfilter,(_,resp)=>{
    resp.sendFile(`${publicpath}/index.html`)
});
app.get('/about',(_,resp)=>{
    resp.sendFile(`${publicpath}/about.html`)
});
//load profile.ejs page view uing ejs package
// user middleware for profile page
// const reqfilter = (req,resp,next)=>{
//     if(!req.query.age){
//         resp.send('Please provide your age to access  page')
//     }
//     else if(req.query.age < 18){
//     resp.send('Not eligibale to access  page')
//     }
//     else{
//         next();
//     }
// }
// app.use(reqfilter);
app.get('/profile',reqfilter,(_,resp)=>{
    const user = {
        name:"Arghya Mukherjee",
        email:"arghya.mukherjee@codeclouds.com",
        city:"Bardhman",
        skills:['php','codeigniter','Laravel','c','c++','mysql','vanila Js','Node','wordpress','shopify']
    };
    resp.render('profile',{user});
});
app.get('*',(_,resp)=>{
    resp.sendFile(`${publicpath}/404.html`);
});



app.listen(5000);
