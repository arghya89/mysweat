<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\CampaignDetails;
use App\Models\User;
use App\Models\crms;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;

class KonnektiveController extends Controller
{
    public function checkCredentials(Request $request)
    {
        $apiUsername = $request->input('apiUsername');
        $apiPassword = $request->input('apiPassword');
        $endpointURL = $request->input('endpointURL');
        if(strpos($endpointURL, 'http://') !== 0 && strpos($endpointURL, 'https://') !== 0){
            $endpointURL = "https://".$endpointURL; 
        }
        
        $apiEndpoint  = $endpointURL; //API endpoint URL 
        //$apiEndpoint = 'https://your-konnektive-crm-api-url.com/auth';

        // Set up authentication credentials
        $authCredentials = base64_encode("$apiUsername:$apiPassword");
        $headers = [
            'Authorization' => "Basic $authCredentials",
        ];

        // Make the GET request to check the credentials
        $response = Http::withHeaders($headers)->get($apiEndpoint);

        if ($response->successful()) {
            return response()->json(['status' => 'success']);
        } else {
            return response()->json(['status' => 'error']);
        }
    }

    public function orderfromCRM($selctedCRM){
        //echo $selctedCRM;die;
        // $id= Auth::user()->id; // get the current userid
         $crmData = crms::find($selctedCRM);
    //dd($crmData);
        
        return response()->json([
            'status' => 'success',
            'crmData' => $crmData,
        ]);
    }
    public function fetchKonnecktivecampaigns(Request $request){

        $url = "https://api.konnektive.com/campaign/query/";
        $data = [
            'loginId' =>  $request->input('knk_username'),
            'password' => $request->input('knk_password')
        ];
        $curl = curl_init();
        curl_setopt_array($curl, array(
                CURLOPT_URL => $url . '?' . http_build_query($data),
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_ENCODING => '',
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 0,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => 'POST',
                 ));
    $response = curl_exec($curl);
    curl_close($curl);
    //dd($response);
    $crmResponse = json_decode($response);
    //echo "<pre>";print_r($crmResponse);die();
    $campaignlist=[];
    $eachcampaign = [];
    foreach ($crmResponse->message->data as $eachOrderData) {
            $eachcampaign['campaignId'] = $eachOrderData->campaignId;
            $eachcampaign['campaignName'] = $eachOrderData->campaignName;
            $campaignlist[]=$eachcampaign;
    }
    //echo "<pre>";print_r($campaignlist);die();
    return response()->json([
        'status' => 'success',
        'campaignlist' => $campaignlist,
    ]);
    }

    public function fetchRetentionReport(Request $request){
        $url = "https://api.konnektive.com/reports/retention/";
        $data = [
                    'loginId'  =>  $request->input('username'),
                    'password' => $request->input('password'),
                    'startDate'=> $request->input('startDate'),
                    'endDate'  => $request->input('endDate'),
                    'campaignId'=> $request->input('campaignId'),
                    'reportType'=>'campaign'
                ]; 
        $curl = curl_init();
        curl_setopt_array($curl, array(
                CURLOPT_URL => $url . '?' . http_build_query($data),
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_ENCODING => '',
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 0,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => 'POST',
                 ));
    $response = curl_exec($curl);
    curl_close($curl);
    //dd($response);
    $crmResponse = json_decode($response);
    //echo "<pre>";print_r($crmResponse);die(); 
    return  $crmResponse;
    }
    //function fetchKonnektiveOrders($apiUsername, $apiPassword, $startDate, $endDate, $campaignId)
    public function orderFetchFromKonnetiveCRM()
    { //die("hh");
    $apiUsername = "dev_api_new";
    $apiPassword = "dev@API@2023";
    $startDate = "07-28-2023";
    $endDate = "08-09-2023";
    $campaignId = "14";
    $url = "https://api.konnektive.com/order/query/";
    $data = [
                'loginId' => $apiUsername,
                'password' => $apiPassword,
                'startDate' => $startDate,
                'endDate' => $endDate,
                'campaignId' => $campaignId,
            ];

    $curl = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_URL => $url . '?' . http_build_query($data),
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
    ));

    $response = curl_exec($curl);
    curl_close($curl);
    //dd($response);
    $crmResponse = json_decode($response);
    //echo "<pre>";print_r($crmResponse);die();
    $finalresult=[];
    $eachOrderId = [];
    foreach ($crmResponse->message->data as $eachOrderData) {
        $eachOrderId['orderId'] = $eachOrderData->orderId;
        $eachOrderId['campaignName'] = $eachOrderData->campaignName;
        $eachOrderId['campaignId'] = $eachOrderData->campaignId;
        $eachOrderId['dateCreated'] = $eachOrderData->dateCreated;
        $eachOrderId['customer_name'] = ucwords($eachOrderData->firstName)." ".ucwords($eachOrderData->lastName);
        $eachOrderId['emailAddress'] = $eachOrderData->emailAddress;
        $eachOrderId['orderStatus'] = $eachOrderData->orderStatus;
        $eachOrderId['cardType'] = $eachOrderData->cardType;
        $eachOrderId['totalAmount'] = $eachOrderData->totalAmount;
        $finalresult[]=$eachOrderId;
    }

    //return $finalresult;
    return response()->json([
        'status' => 'success',
        'finalresult' => $finalresult,
    ]);
}

public function fetchgraphReport(Request $request){
echo "<pre>";print_r($request);
}

}





