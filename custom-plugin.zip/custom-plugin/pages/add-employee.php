<?php
$message = "";
$status = "";
$action = "";
$empid = "";
if(isset($_GET['empId']) && isset($_GET['action'])){
    if($_GET['action'] == "edit"){
        $action ="edit";
    }
    if($_GET['action'] == "view"){
        $action ="view";
     }
    $empid = $_GET['empId'];
    // get single data information
    global $wpdb,$table_prefix;
    $employee = $wpdb->get_row(
        $wpdb->prepare("SELECT * FROM ".$table_prefix."employee_management_system WHERE id= %d",$empid),ARRAY_A);
    //echo $action;
}
if($_SERVER['REQUEST_METHOD'] == "POST" && isset($_POST['from_btn_submit'])){
global $wpdb,$table_prefix;
$name = sanitize_text_field($_POST['name']);
$email = sanitize_text_field($_POST['email']);
$address = sanitize_text_field($_POST['address']);
$phone = sanitize_text_field($_POST['phone']);
$designation = sanitize_text_field($_POST['designation']);
$gender = sanitize_text_field($_POST['gender']);

if($_POST['empID'] !=""){
    $updatedId =$_POST['empID'];
    $wpdb->update($table_prefix.'employee_management_system',array(
        'name'=>$name,
        'email'=>$email,
        'address'=>$address,
        'phone'=>$phone,
        'designation'=> $designation,
        "gender"=>$gender
    ),array('id'=>$updatedId));
    
       $status = 1;
        $message ="Employee updated successfully";
}else{

    $wpdb->insert($table_prefix.'employee_management_system',array(
        'name'=>$name,
        'email'=>$email,
        'address'=>$address,
        'phone'=>$phone,
        'designation'=> $designation,
        "gender"=>$gender
    ));
    $last_insert_id = $wpdb->insert_id;
    if($last_insert_id >0){
       echo  $status = 1;
        $message ="Employee inserted successfully";
    }else{
        $status = 0;
        $message ="Failed to insert data";
    }
}

}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Add Employee</title>
  <link rel="stylesheet" href="<?php echo EMS_PLUGIN_URL; ?>css/bootstrap.min.css">
  <style>
    #ems-add-employee label.error{
        color:red;
        font-weight:500;
    }
  </style>
</head>
<body>
  <div class="container mt-5">
    <div class="card  col-sm-8" style="background:#f8f8f9">
      <div class="card-header" style="background:#5be982">
     <?php  if( $action =="view"){  ?>
        <h2 class="mb-0">View Employee</h2>
        <?php } else if($action =="edit") { ?>
            <h2 class="mb-0">Edit Employee</h2>
          <?php } else{ ?>
            <h2 class="mb-0">Add Employee</h2>
          <?php }  ?>
      </div>
      <div class="card-body">
        <img src="<?php echo EMS_PLUGIN_URL; ?>images/default.png" style="width:100px">
        <?php if($status == 1){?>
            <div class="alert alert-success">
                <?php echo $message; ?>
                </div>
            <?php }else if($message == 0) { ?>
                <div class="alert alert-danger">
                <?php echo $message; ?>
                </div>
            <?php } ?>
        <form action="<?php if ($action ="edit"){ echo 'admin.php?page=employee-management&action=edit&empId='.$employee['id']; }else { echo $_SERVER['PHP_SELF']; ?>?page=employee-management<?php } ?>" method="post" id="ems-add-employee">
          <div class="form-group">
            <?php if($action =="edit"){ ?>
            <input type="hidden" name="empID" value="<?php echo $employee['id']; ?>">    
            <?php } ?>
            <label for="name">Name</label>
            <input name="name" type="text" class="form-control" id="name" placeholder="Enter name" value="<?php if(isset($_GET['empId']) && isset($_GET['action'])) { echo $employee['name'];} ?>" required <?php if($action =="view"){ echo "readonly = 'readonly'";} ?>>
          </div>
          <div class="form-group">
            <label for="email">Email</label>
            <input name="email" type="email" class="form-control" id="email" placeholder="Enter email" value="<?php if(isset($_GET['empId']) && isset($_GET['action'])) { echo $employee['email'];} ?>" required <?php if($action =="view"){ echo "readonly = 'readonly'";} ?>>
          </div>
          <div class="form-group">
            <label for="address">Address</label>
            <input name="address" type="text" class="form-control" id="address" placeholder="Enter address" value="<?php if(isset($_GET['empId']) && isset($_GET['action'])) { echo $employee['address'];} ?>" required <?php if($action =="view"){ echo "readonly = 'readonly'";} ?>>
          </div>
          <div class="form-group">
            <label for="phone">Phone Number</label>
            <input name="phone" type="text" class="form-control" id="phone" placeholder="Enter phone number" value="<?php if(isset($_GET['empId']) && isset($_GET['action'])) { echo $employee['phone'];} ?>" required <?php if($action =="view"){ echo "readonly = 'readonly'";} ?>>
          </div>
          <div class="form-group">
            <label for="email">Designation</label>
            <input type="text" name="designation" class="form-control" id="designation" placeholder="Enter address" value="<?php if(isset($_GET['empId']) && isset($_GET['action'])) { echo $employee['designation'];} ?>" required <?php if($action =="view"){ echo "readonly = 'readonly'";} ?>>
          </div>
          <div class="form-group">
            <label for="email">Gender</label>
            <select name="gender" id="gender" class="form-control" required <?php if($action =="view"){ echo "disabled";} ?>>
            <option value="">Select Gender</option>
                <option value="male" <?php if($employee['gender'] =='male') {echo "selected";} ?>>Male</option>
                <option value="female" <?php if($employee['gender'] =='female') {echo "selected";} ?>>Female</option>
                <option value="other" <?php if($employee['gender'] =='other') {echo "selected";} ?>>Other</option>
            </select>
          </div>
          <?php  if($action =="view"){ ?>
            View Employee
          <?php } else if ($action =="edit") {?>
            <button type="submit" class="btn btn-primary" name="from_btn_submit">Update</button>
           <?php }else{ ?>
            <button type="submit" class="btn btn-primary" name="from_btn_submit">Submit</button>
            <?php } ?>
        </form>
      </div>
    </div>
  </div>

  <!--Bootstrap JS -->
   <script src="<?php echo EMS_PLUGIN_URL; ?>js/jquery-3.5.1.slim.min.js"></script>
  <script src="<?php echo EMS_PLUGIN_URL; ?>js/popper.min.js"></script>
  <script src="<?php echo EMS_PLUGIN_URL; ?>js/bootstrap.min.js"></script>
  <script src="<?php echo EMS_PLUGIN_URL; ?>js/jquery.validate.min.js"></script>
  <script>
	// $.validator.setDefaults({
	// 	submitHandler: function() {
	// 		alert("submitted!");
	// 	}
	// });

	$().ready(function() {
		// validate signup form on keyup and submit
		$("#ems-add-employee").validate({
			rules: {
				name: {
					required: true,
					minlength: 2
				},
				email: {
					required: true,
					email: true
				},
				address: {
					required: true,
					minlength: 2
				},
                phone: {
					required: true,
					minlength: 10
				},
				designation: {
					required: true,
					minlength: 2
				},
                gender: "required",
			},
			messages: {
				name: {
					required: "Please enter a name",
					minlength: "please enter a valid name"
				},
				email: "Please enter a valid email address",
                address: {
					required: "Please enter a address",
					minlength: "please enter a valid address"
				},
                phone: {
					required: "Please enter  phone number",
					minlength: "please enter a valid phone number"
				},
                designation: {
					required: "Please enter a designation",
					minlength: "please enter a valid designation"
				},
                
				gender: "Please select gender"
			}
		});

		// propose username by combining first- and lastname
		$("#username").focus(function() {
			var firstname = $("#firstname").val();
			var lastname = $("#lastname").val();
			if (firstname && lastname && !this.value) {
				this.value = firstname + "." + lastname;
			}
		});
    });
        </script>
</body>
</html>
