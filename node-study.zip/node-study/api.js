const express = require('express');
const dbconnect = require ('./mongodb');
const app = express();

// basic to fetch all the data from database (mongocluster)
app.get('/',async(req,resp)=>{
    const db = await dbconnect();
    let alldata = await db.find().toArray();
resp.send(alldata)
});
app.listen(4000);
