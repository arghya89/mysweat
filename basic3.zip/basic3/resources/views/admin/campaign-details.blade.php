@extends('admin.admin-master')
@section('admin')
<div class="page-content">
                    <div class="container-fluid">

                        <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                                    <h4 class="mb-sm-0">Data Tables</h4>

                                    <div class="page-title-right">
                                        <ol class="breadcrumb m-0">
                                            <li class="breadcrumb-item"><a href="javascript: void(0);">Tables</a></li>
                                            <li class="breadcrumb-item active">Data Tables</li>
                                        </ol>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <!-- end page title -->
                        <select id="selctcRm" name="CRM">
                            <option>Choose CRM</option>
                            @foreach($listedCRM as $crm)
                                    <option value="{{ $crm->id }}">{{ $crm->crm_name }}</option>
                                    @endforeach
                            </select>
                        <div class="row">
                            <div class="col-12">
                                <div class="card">
                                    <div class="card-body">
                                    
                                        <h4 class="card-title">Default Datatable</h4>
                                        <p class="card-title-desc">DataTables has most features enabled by
                                            default, so all you need to do to use it with your own tables is to call
                                            the construction function: <code>$().DataTable();</code>.
                                        </p>
                                        <div id="tableContainer"></div>
                                        <table id="datatable" class="table sticky table-bordered dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                                            <thead>
                                            <tr>
                                                <th>Campaign Name(Id)</th>
                                                <th>Campaign Type</th>
                                                <th>Created At</th>
                                                <th>Last updated</th>
                                                <th>Time Zone</th>
                                                <th>Status</th>
                                                <th>View orders</th>
                                            </tr>
                                            </thead>
        

                                            <tbody>
                                                @foreach($campainData as $data)
                                                
                                            <tr>
                                                <td>{{ $data->campaign_name }} <b>({{ $data->campaign_id }})</b></td>
                                                <td> @if($data->is_prepaid_blocked == 1) <span style ="font-weight:bold;color:red;">Prepaid</span> @else <span style ="font-weight:bold;color:green;">Non Prepaid </span> @endif</td>
                                                <td>{{ $data->created_at }}</td>
                                                <td>{{ $data->updated_at }}</td>
                                                <td>{{ $data->time_zone }}</td>
                                                <td> @if($data->is_active == 1) <span style ="font-weight:bold;color:green;">Active</span> @else <span style ="font-weight:bold;color:red;">Disabled </span> @endif</td>
                                                <td><a href="{{route('admin.fetchOrders',$data->campaign_id)}}">View orders </a></td>
                                            </tr>
                                            @endforeach
                                            
                                            </tbody>
                                        </table>
        
                                    </div>
                                </div>
                            </div> <!-- end col -->
                        </div> <!-- end row -->
        
                        
                        
                    </div> <!-- container-fluid -->
                </div>
                @endsection