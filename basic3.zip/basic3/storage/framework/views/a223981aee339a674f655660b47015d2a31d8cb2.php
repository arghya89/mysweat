
<?php $__env->startSection('admin'); ?>
<div class="main-content">

                <div class="page-content">
                    <div class="container-fluid">

                        <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                                    <h4 class="mb-sm-0">ADD YOUR CRM</h4>

                                    <div class="page-title-right">
                                        <ol class="breadcrumb m-0">
                                            <li class="breadcrumb-item"><a href="javascript: void(0);">Forms</a></li>
                                            <li class="breadcrumb-item active">Forms Elements</li>
                                        </ol>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <!-- end page title -->
                        <div id="alertDiv"></div>
                        <form name="registrationForm" class="form-horizontal mt-3" method="POST" action="<?php echo e(route('admin.storeCRM')); ?>"  enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-12">
                                <div class="card">
                                    <div class="card-body">

                                        <div class="row mb-3">
                                            <label for="example-text-input" class="col-sm-2 col-form-label">Name</label>
                                            <div class="col-sm-10">
                                                <input class="form-control" name="crm_name" value="" type="text" placeholder="Artisanal kale" id="example-text-input">
                                                <?php $__errorArgs = ['crm_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                        <!-- end row -->
                                        <div class="row mb-3">
                                            <label for="example-search-input" class="col-sm-2 col-form-label">username</label>
                                            <div class="col-sm-10">
                                                <input class="form-control" type="text" value=""name="username" placeholder="How do I shoot web" id="username">
                                                <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                        <!-- end row -->
                                        <div class="row mb-3">
                                            <label for="example-email-input" class="col-sm-2 col-form-label">password</label>
                                            <div class="col-sm-10">
                                                <input class="form-control" value="" name="password" type="text" id="password">
                                            </div>
                                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="row mb-3">
                                            <label for="example-email-input" class="col-sm-2 col-form-label">URL</label>
                                            <div class="col-sm-10">
                                                <input class="form-control" value="" name="url" type="url" placeholder="bootstrap@example.com" id="url">
                                            </div>
                                            <?php $__errorArgs = ['url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <!-- end row -->
                                        
                                        
                                        <!-- end row -->
                                        <div class="row justify-content-center">
                                        <div class="col-4">
                                        <button class="btn btn-primary" type="submit" style="margin-left: 15rem;">Add CRM</button>
                                        </div>
                                        <div class="col-4">
                                        <!-- <input type="submit" class="form-control" value="Update">  -->
                                        <button class="btn btn-primary" type="submit">Update Your Info</button>
                                        </div>
                                        <div class="col-4">
                                        <!-- <input type="submit" class="form-control" value="Update">  -->
                                        <button class="btn btn-primary" id="checkCredentialsButton" type="button">Check the Validation</button>
                                        </div>
                                        </div>
                                    </div>
                                </div>
                            </div> <!-- end col -->
                        </div>
                </form>
                        <!-- end row -->
                        <!-- end row -->
                    </div> <!-- container-fluid -->
                </div>
                <!-- End Page-content -->
            </div>
            <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script> 
            <script>
            $(document).ready(function() {
    $('#checkCredentialsButton').click(function() {
        var apiUsername = $('#username').val();
        var apiPassword = $('#password').val();
        var endpointURL = $('#url').val();
console.log(apiUsername+apiPassword+endpointURL);
        $.ajax({
            type: 'POST',
            url: '/check-konnektive-credentials',
            data: {
                apiUsername: apiUsername,
                apiPassword: apiPassword,
                endpointURL:endpointURL,
                _token: $("input[name=_token]").val(),
            },
            success: function(response) {
                if (response.status === 'success') {
                    // Credentials are valid
                    $("#alertDiv").addClass("alert alert-success");
                    console.log('Credentials are valid.');
                    $("#alertDiv").html('Credentials are valid.');
                    // You can perform any actions you want here.
                } else {
                    // Credentials are invalid
                    console.log('Invalid credentials.');
                    $("#alertDiv").addClass("alert alert-danger");
                    $("#alertDiv").html('Invalid credentials.');
                    // You can handle invalid credentials here, e.g., show an error message.
                }
                showAlertAndDisable();
            },
            error: function(xhr, status, error) {
                // AJAX error handling
                console.log('AJAX error:', status, error);
            },
        });
    });
    function showAlertAndDisable() {
            $('#alertDiv').fadeIn('slow', function() {
                setTimeout(function() {
                    $('#alertDiv').fadeOut('slow', function() {
                        // After fadeOut, disable the div by adding the "disabled" attribute
                        $('#alertDiv').attr('disabled', true);
                    });
                }, 5000); // 5000 milliseconds = 5 seconds
            });
        }
});  
</script>    


<?php echo $__env->make('admin.admin-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp8\htdocs\practicelaravel\basic3\resources\views/admin/addCRM.blade.php ENDPATH**/ ?>