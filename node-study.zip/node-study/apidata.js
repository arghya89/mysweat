data = [
    {name:'Arghya Mukherjee',email:'arghya.mukherjee@codeclouds.in'},
    {name:'Abhijeet Kundu',email:'abhijeet.kundu@codeclouds.in'}
]
module.exports =data;