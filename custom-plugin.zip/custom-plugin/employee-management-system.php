<?php
/*
*Plugin Name: Employee Management System
*Description: This For Employee Management System CRUD
*plugin URI: https://test.com
*Author:Arghya Mukherjee
*author URI: https://test.com
*version:1.0
*/
define('EMS_PLUGIN_PATH',plugin_dir_path(__FILE__));
define('EMS_PLUGIN_URL',plugin_dir_url(__FILE__));
// action hook to call menu
add_action('admin_menu','cp_add_adminmenu');
function cp_add_adminmenu(){
    add_menu_page('Employee System','Employee System','manage_options','employee-management','employee_management_handle','dashicons-admin-multisite',19);
    // add submenu
    //add_submenu_page('employee-management','Add Employee','Add Employee','manage_options','add-employee','ems_add_employee_handle');
    /* comment the above code becuse I want to open the add employee page whenever anyone clicks on Employee System */
    add_submenu_page('employee-management','Add Employee','Add Employee','manage_options','employee-management','employee_management_handle');
    add_submenu_page('employee-management','List Employee','List Employee','manage_options','list-employee-management','list_employee_management_handle');
}
function employee_management_handle(){
include_once(EMS_PLUGIN_PATH."/pages/add-employee.php");
}
/******** SUB MENU CALL BACK FUNCTION ******************/
// function ems_add_employee_handle(){
//     echo "<h2>Add Employee</h2>";
// }
function list_employee_management_handle(){
    include_once(EMS_PLUGIN_PATH."/pages/list-employee.php");
}

register_activation_hook(__FILE__,'create_table');
function create_table(){
    global $wpdb,$table_prefix;
    $table = $table_prefix."employee_management_system";
    $sql = "CREATE TABLE IF NOT EXISTS {$table} (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `name` varchar(255) NOT NULL,
        `email` varchar(255) NOT NULL,
        `phone` varchar(255) NOT NULL,
        `designation` varchar(255) NOT NULL,
        `address` varchar(255) NOT NULL,
        `gender` varchar(255) NOT NULL,
        PRIMARY KEY (`id`)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
      //$wpdb->query($sql_query);
      include_once(ABSPATH . 'wp-admin/includes/upgrade.php');
      dbDelta($sql);
      // create wordpress page
      $page_data =array(
        'post_title'=>'Employee management System',
        'post_status'=>'publish',
        'post_type'=>'page',
        'post_content'=>'This is a simple page',
        'post_name'=>'employee-management-system'
      );

      wp_insert_post($page_data);// to create apage upon activation on plugin
}

register_deactivation_hook(__FILE__,'truncate_table_upon_deactivation');
function truncate_table_upon_deactivation(){
    global $wpdb,$table_prefix;
    $table = $table_prefix."employee_management_system";
    $truncate_sql = "TRUNCATE `$table`";
    $wpdb->query($truncate_sql);
    // include_once ABSPATH."wp-admin/includes/upgrade.php";
    //   dbDelta($truncate_sql);

    // DELETE THE PAGE UPON DEACTIVATION OF PLUGIN
    $page_slug = "employee-management-system";
    $pageInfo = get_page_by_path($page_slug); // get all the information of the page
    $pageId = $pageInfo->ID; // get the page id
    wp_delete_post($pageId,true); // Force delete if we pass true so that the page do not palce into the trash section
}

// add_action('admin_enqueue_scripts','employee_manage_system_scripts');
// function employee_manage_system_scripts(){
//     wp_enqueue_style('ems-bootsrap.min',EMS_PLUGIN_URL.'css/bootstrap.min.css',array(),'1.0.0','all');
//     wp_enqueue_style('ems-dataTables.bootstrap4.min',EMS_PLUGIN_URL.'css/dataTables.bootstrap4.min.css',array(),'1.0.0','all');
    
//     wp_enqueue_script('ems-bootstrap',EMS_PLUGIN_URL.'js/bootstrap.min.js',array('jquery'),'1.0.0');
//     wp_enqueue_script('ems-slim.min',EMS_PLUGIN_URL.'js/jquery-3.5.1.slim.min.js',array(),'1.0.0');
//     wp_enqueue_script('ems-dataTables',EMS_PLUGIN_URL.'js/dataTables.bootstrap4.min.js',array(),'1.0.0');
//     wp_enqueue_script('ems-custom',EMS_PLUGIN_URL.'js/custom.js',array('jquery'),'1.0.0');
// }