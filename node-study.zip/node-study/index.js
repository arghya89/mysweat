const dbconnect = require('./mongodb');

const main = async()=>{
        let data = await dbconnect();
        data = await data.find().toArray();
        console.log(data);
    }
    
    main();

    /***************************************************************************************************************** */
    // const {MongoClient} = require('mongodb');
    // const url= "mongodb+srv://arghyammukherjee:arghyammukherjee@leaning-purpose.qdaigp8.mongodb.net/?retryWrites=true&w=majority&appName=leaning-purpose";
    // const database = "test";
    // const client = new MongoClient(url);
    
    /* there are 3 different types of pattern to connect the db and fetch the data from db **********/
    
    /****************** FIRST WAY uncomment the the collection response inside the dbconnect method */
// async function dbconnect()
// {
// let connection = await client.connect();
// let db = connection.db(database);
// return db.collection('users');
//let collection = db.collection('users');
// let response = await collection.find({}).toArray();
// console.log(response);
//}

/********************** 2 nd way ************************/
// dbconnect().then((resp)=>{
// resp.find({company:"Apple"}).toArray().then((data)=>{
//     console.log(data);
// });
// });
/********************** third way ************************/
// const main = async()=>{
//     let data = await dbconnect();
//     data = await data.find().toArray();
//     console.log(data);
// }

// main();