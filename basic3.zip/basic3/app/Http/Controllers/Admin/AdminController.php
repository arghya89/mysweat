<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\crms;
use App\Models\CampaignDetails;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Http;
use App\Helpers\myUniqueCustomHelper;


class AdminController extends Controller
{
    public function logout(){
        Session::flush();
        Auth::logout();
        $notification = array(
            "message"=>"Profile created successfully",
            "alert-type"=>"success");
        return redirect('login')->with($notification);

    }
    public function profile(){
        $id= Auth::user()->id; // get the current userid
        $adminData = User::find($id); //get the current user data
        //echo"<pre>";print_r($adminData);die();
        return view('admin.admin_profile_view',compact('adminData'));
        //return view('admin.admin_profile_view');
    } 
    public function store_profile(Request $post){
        //return $post->username;die;
         $id= Auth::user()->id; // get the current userid
         $data = User::find($id); //get the current user data
         $data->name = $post->name;
         $data->username = $post->username;
         $data->address = $post->address;
         $data->dob = $post->dob;
         $data->email = $post->email;
         $data->phone_number = $post->phone_number;
         if($post->file('profile_image')){
             $file= $post->file('profile_image');
             $filename= time().$file->getClientOriginalName();
             $file->move(public_path('upload/profile_images'),$filename);
             $data['profile_image'] = $filename;
 
         }
         $data->save();
         $notification = array(
             "message"=>"Profile upated successfully",
             "alert-type"=>"success"
         );
         return redirect()->route('userdashboard')->with($notification);
     }
     public function showAlltheCampaigns(){
        $adminid= Auth::user()->id; // get the current userid
        $model = new CampaignDetails();
        $campainData = $model->getAlltheCamaigninfo($adminid);
        $crm_model = new crms();
        $listedCRM = $crm_model->getAllthelistedCRM($adminid);
        //echo"<pre>";print_r($campainData);die();

        return view('admin.campaign-details',compact('campainData','listedCRM'));
     }
     public function listedcrm(){
        $adminid= Auth::user()->id; // get the current userid
        $model = new crms();
        $listedCRM = $model->getAllthelistedCRM($adminid);
        return view('admin.listedCRM',compact('listedCRM'));
    }

    public function fetchCampaignsFromSelectedCRM(Request $request){
        $selectedCRM = $request->input('selctedCRM');
        $adminid= Auth::user()->id; // get the current userid
        $model = new CampaignDetails();
    }

    public function crm(){
        return view('admin.addCRM');
    }

    public function storeCRM(Request $post){
        $post->validate([
           'crm_name'=>'required',
            'username'=>'required',
            'password'=>'required',
            'url'=>'required',
        ],
        [
            'crm_name.required'=>'CRM Name required',
            'username.required'=>'Username  required',
            'password.required'=>'Password required',
            'url.required'=>'URL is required',
        ]);
        crms::insert([
                    'crm_name' => $post->crm_name,
                    'username'=>$post->username,
                    'password'=>$post->password,
                    'url'=>$post->url,
                    'status'=> 1,
                    'user_id'=>Auth::user()->id,
                    ]);
        $notification = array(
            "message"=>"CRM added successfully",
            "alert-type"=>"success"
        );
        //return redirect()->back()->with($notification);
        return redirect()->route('admin.listedcrm')->with($notification);
        //return view('admin.addCRM');
    }

    public function fetchOrders($campaignId){
        $crmData = myUniqueCustomHelper::getTheSelectedCRM();
        //dd($crmData);
        $crmApiUsername = $crmData[0]['username'];
        $crmApiPassword = $crmData[0]['password'];
                $crmUrl = $crmData[0]['url'];
                //$SelectedCampaignOrderDetails =  myUniqueCustomHelper::getOrderDetails($campaignId,$crmApiUsername,$crmApiPassword,$crmUrl);
        $SelectedCampaignOrderDetails =  myUniqueCustomHelper::getOrderDetails($campaignId,$crmApiUsername,$crmApiPassword);
        echo "<pre>";print_r($SelectedCampaignOrderDetails);
        //return view('admin.showAllorders');
    }

    //public function fetchOrders($campaignId){

}
