
  <div class="container mt-5">
    <h2 style="background-color: #007bff; color: white; padding: 10px;">Student List</h2>
    <table id="employeeTable" class="table table-striped table-bordered">
    <?php if(isset($status)&&($status == 1)){?>
            <div class="alert alert-success">
                <?php echo $message; ?>
                </div>
            <?php }  ?>
      <thead>
        <tr>
          <th>ID</th>
          <th>Name</th>
          <th>Email</th>
          <th>Phone Number</th>
          <th>Gender</th>
          <th>#Action</th>
        </tr>
      </thead>
      <tbody>
        <?php if(count($students)> 0){

        foreach($students as $student){ ?>
      
        <tr>
          <td><?php echo $student['id']; ?></td>
          <td><?php echo ucwords($student['name']); ?></td>
          <td><?php echo $student['email']; ?></td>
          <td><?php echo $student['phone']; ?></td>
          <td><?php echo ucfirst($student['gender']); ?></td>
          <td>
            <div class="btn-group" role="group">
              <a href="admin.php?page=student-system&action=edit&studentId=<?php echo $student['id']; ?>" class="btn btn-warning">Edit</a>&nbsp;
              <form id="frm-id-<?php echo $student['id'] ?>" method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>?page=student-system">
              <input type="hidden" name="delte-id" value="<?php echo $student['id']; ?>">
            </form>
              <a href="javascript:void(0);" onclick="if(confirm('Are you sure you want to delete')){
                jQuery('#frm-id-<?php echo $student['id'] ?>').submit(); }"
             class="btn btn-danger">Delete</a>&nbsp;
              <a href="admin.php?page=student-system&action=view&studentId=<?php echo $student['id']; ?>" class="btn btn-info">View</a>
            </div>
          </td>
        </tr>
        <?php } }else{ ?>
          <tr> No data Found </tr>
          <?php } ?>
      </tbody>
    </table>
  </div>
