<!doctype html>
<html lang="en">

    <head>
        
        <meta charset="utf-8" />
        <title>Dashboard | Upcube - Admin & Dashboard Template</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta content="Premium Multipurpose Admin & Dashboard Template" name="description" />
        <meta content="Themesdesign" name="author" />
        <!-- App favicon -->
        <link rel="shortcut icon" href="{{ asset('assets/images/favicon.ico')}}">

        <!-- jquery.vectormap css -->
        <link href="{{ asset('assets/libs/admin-resources/jquery.vectormap/jquery-jvectormap-1.2.2.css')}}" rel="stylesheet" type="text/css" />

        <!-- DataTables -->
        <link href="{{ asset('assets/libs/datatables.net-bs4/css/dataTables.bootstrap4.min.css')}}" rel="stylesheet" type="text/css" />
        <link href="{{ asset('assets/libs/datatables.net-buttons-bs4/css/buttons.bootstrap4.min.css')}}" rel="stylesheet" type="text/css" />
        <link href="{{ asset('assets/libs/datatables.net-select-bs4/css//select.bootstrap4.min.css')}}" rel="stylesheet" type="text/css" />

        <!-- Responsive datatable examples -->
        <link href="{{ asset('assets/libs/datatables.net-responsive-bs4/css/responsive.bootstrap4.min.css')}}" rel="stylesheet" type="text/css" />  

        <!-- Bootstrap Css -->
        <link href="{{ asset('assets/css/bootstrap.min.css')}}" id="bootstrap-style" rel="stylesheet" type="text/css" />
        <!-- Icons Css -->
        <link href="{{ asset('assets/css/icons.min.css')}}" rel="stylesheet" type="text/css" />
        <!-- App Css-->
        <link href="{{ asset('assets/css/app.min.css')}}" id="app-style" rel="stylesheet" type="text/css" />

    </head>

    <body data-topbar="dark">
    
    <!-- <body data-layout="horizontal" data-topbar="dark"> -->

        <!-- Begin page -->
        <div id="layout-wrapper">
            @include('admin.navbar')

            <!-- ========== Left Sidebar Start ========== -->
            @include('admin.leftsidebar')
            <!-- Left Sidebar End -->
            <!-- ============================================================== -->
            <!-- Start right Content here -->
            <!-- ============================================================== -->
            <div class="main-content">
            @yield('admin')
            @include('admin.footer')
            </div>
            <!-- end main content-->

        </div>
        <!-- END layout-wrapper -->

        <!-- Right Sidebar -->
        <div class="right-bar">
            <div data-simplebar class="h-100">
                <div class="rightbar-title d-flex align-items-center px-3 py-4">
            
                    <h5 class="m-0 me-2">Settings</h5>

                    <a href="javascript:void(0);" class="right-bar-toggle ms-auto">
                        <i class="mdi mdi-close noti-icon"></i>
                    </a>
                </div>

            </div> /**-- end slimscroll-menu--*/
        </div>
        <!-- /Right-bar -->

        <!-- Right bar overlay-->
        <div class="rightbar-overlay"></div>

        <!-- JAVASCRIPT -->
        <script src="{{ asset('assets/libs/jquery/jquery.min.js')}}"></script>
        <script src="{{ asset('assets/libs/bootstrap/js/bootstrap.bundle.min.js')}}"></script>
        <script src="{{ asset('assets/libs/metismenu/metisMenu.min.js')}}"></script>
        <script src="{{ asset('assets/libs/simplebar/simplebar.min.js')}}"></script>
        <script src="{{ asset('assets/libs/node-waves/waves.min.js')}}"></script>

        
        <!-- apexcharts -->
        <script src="{{ asset('assets/libs/apexcharts/apexcharts.min.js')}}"></script>

        <!-- jquery.vectormap map -->
        <script src="{{ asset('assets/libs/admin-resources/jquery.vectormap/jquery-jvectormap-1.2.2.min.js')}}"></script>
        <script src="{{ asset('assets/libs/admin-resources/jquery.vectormap/maps/jquery-jvectormap-us-merc-en.js')}}"></script>

        <!-- Required datatable js -->
        <script src="{{ asset('assets/libs/datatables.net/js/jquery.dataTables.min.js')}}"></script>
        <script src="{{ asset('assets/libs/datatables.net-bs4/js/dataTables.bootstrap4.min.js')}}"></script>
        
        <!-- Responsive examples -->
        <script src="{{ asset('assets/libs/datatables.net-responsive/js/dataTables.responsive.min.js')}}"></script>
        <script src="{{ asset('assets/libs/datatables.net-responsive-bs4/js/responsive.bootstrap4.min.js')}}"></script>

        <script src="{{ asset('assets/libs/datatables.net-keytable/js/dataTables.keyTable.min.js')}}"></script>
        <script src="{{ asset('assets/libs/datatables.net-select/js/dataTables.select.min.js')}}"></script>

        <script src="{{ asset('assets/js/pages/dashboard.init.js')}}"></script>
        <script src="{{ asset('assets/js/pages/datatables.init.js')}}"></script>
        <!-- App js -->
        <script src="{{ asset('assets/js/app.js')}}"></script>
        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <!-- <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script> -->
    <!-- Include Bootstrap Datepicker CSS -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/css/bootstrap-datepicker.min.css">

<!-- Include jQuery (required for Bootstrap Datepicker) -->
<!-- <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script> -->

<!-- Include Bootstrap JavaScript and Bootstrap Datepicker JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/js/bootstrap-datepicker.min.js"></script>
<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>

<script>
    $(document).ready(function() {
        
        $('#choosecRm').change(function() {
            var selectedCRM = $(this).val();
            console.log(selectedCRM);
            $.ajax({
                    type: 'GET',
                    url: '/orderfromCRM/'+selectedCRM,
                    success: function(response) 
                        {
                            console.log(response);
                        if (response.status === 'success') {
                            var crmData = response.crmData;
                                if(response.crmData.type == 2){
                                    console.log(response.crmData.username);
                                    localStorage.setItem('crmusername',response.crmData.username);
                                    localStorage.setItem('crmPassword',response.crmData.password);
                                    $("#crmpass").val(response.crmData.password);
                                    console.log(response.crmData.password);
                                    $.ajax({
                                        type: 'POST',
                                        url: '/campaignsdetails',
                                        data: {
                                                knk_username:response.crmData.username,
                                                knk_password:response.crmData.password,
                                                
                                            },
                                       
                                        success: function(crmresponse)
                                                {
                                                console.log(crmresponse);
                                                var newDropdown ='<div class="form-group"><label for="dropdownOptions">Select an Option:</label>';
                                                newDropdown +='<select class="form-control" id="dropdownOptions"><option>Select Campaign</option>';
                                                for (var i = 0; i < crmresponse.campaignlist.length; i++) {
                                                    var rowData = crmresponse.campaignlist[i];
                                                    newDropdown +='<option value="'+ rowData.campaignId+'">'+rowData.campaignName+'( '+rowData.campaignId+' )</option>';
                                                    newDropdown +="</option>";
                                                }
                                                newDropdown +='</select></div>';
                                                $('#cmpdropdownsection').html(newDropdown);
                                               
                                                            
                                                }
                                            });                     
                                    $("#knk_seachoptions").css("display","block");
                                    $("#knk_result_card").css("display","flex");
                                }else{
                                    $("#knk_seachoptions").css("display","none");
                                    $("#knk_result_card").css("display","none");
                                }
                            }
                         }
                        });
             });
        $('#selctcRm').change(function() {
            // Get the selected value
            var selctedCRM = $(this).val();
            //console.log(selctedCRM);
            $.ajax({
                    type: 'GET',
                    url: '/orderfromCRM/'+selctedCRM,
                    // data: {
                    //     selctedCRM:selctedCRM,
                    // },
                    success: function(response) {
                        //console.log(response);
                        if (response.status === 'success') {
                            var crmData = response.crmData;
                            //console.log(response.crmData);
                            if(response.crmData.type == 2){
                                $.ajax({
                                        type: 'GET',
                                        url: '/getordersFromKNK',
                                        // data: {
                                        // someData: crmData.someValue, // we can make it more dyanamic later by passing the date,campaign ids
                                        // },
                                        success: function(crmresponse) {
                                            console.log(crmresponse.finalresult.length);
                                            $('#datatable').hide();
                                            var newTableHTML = '<table id="newDatatable" class="table knk table-bordered dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">';
                                            newTableHTML += '<thead><tr><th>Campaign Name(Id)</th><th>OrderId</th><th>Created At</th><th>Customer Name</th><th>Email address</th><th>Order Status</th><th>cardType</th><th>Order Total</th><th>View Order</th></tr></thead>';
                                            newTableHTML += '<tbody>';

                                            for (var i = 0; i < crmresponse.finalresult.length; i++) {
                                               
                                                var rowData = crmresponse.finalresult[i];
                                                console.log(rowData.campaignName);
                                                newTableHTML += '<tr>';
                                                newTableHTML += '<td>' + rowData.campaignName + ' <b>(' + rowData.campaignId + ')</b></td>';
                                                newTableHTML += '<td>' + rowData.orderId + '</td>';
                                                newTableHTML += '<td>' + rowData.dateCreated + '</td>';
                                                newTableHTML += '<td>' + rowData.customer_name + '</td>';
                                                newTableHTML += '<td>' + rowData.emailAddress + '</td>';
                                                newTableHTML += '<td>' + rowData.orderStatus + '</td>';
                                                newTableHTML += '<td>' + rowData.cardType + '</td>';
                                                newTableHTML += '<td>' + rowData.totalAmount + '</td>';
                                                newTableHTML += '<td><a href="javascript:void(0);" class="view-order-link">View orders </a></td>';
                                                newTableHTML += '</tr>';
                                            }

                                            newTableHTML += '</tbody></table>';

                                            // Append the new table to the container
                                            $('#tableContainer').html(newTableHTML);
                                        },
                                        error: function(xhr, status, error) {
                                            console.log('AJAX error:', status, error); // Handle AJAX error for the second call
                                        }
                                     });
                            }else{
                                console.log('sticky CRM');
                            }
                        }
                                            
                    }
                   
                });
        });
        
        /*$("#searchbtn").click(function(){
            var startDate = $("#startDate").val();
            var endDate = $("#endDate").val();
            var campaignId = $("#dropdownOptions").val();
            var username= localStorage.getItem('crmusername');
            var password= $("#crmpass").val();
            //alert(password);
            //console.log($("#startDate").val()+"===>"+$("#endDate").val()+"campaign id==>"+$("#dropdownOptions").val()+"==>"+username+"==>"+password);
            $.ajax({
                    type: 'POST',
                    url: '/fetchRetentionReport',
                    data: {
                            username:username,
                            password:password,
                            startDate:startDate,
                            endDate:endDate,
                            campaignId:campaignId
                            },
                    success: function(crmresponse) {
                        console.log(crmresponse);
                        $("#total_orders").html(crmresponse.message.Total.orders);
                        $("#total_expense").html(crmresponse.message.Total.expensesTotal);
                        $("#total_gross").html(crmresponse.message.Total.grossTotal);
                        $("#total_net").html(crmresponse.message.Total.netTotal);
                        console.log(crmresponse.message.Total.orders);
                        cycles = crmresponse.message.Total.cycles;
                        //cycles = crmresponse.message.Total.cycles;
                        console.log(cycles);
                        //google.charts.load('current', {'packages':['corechart']});
                        //google.charts.setOnLoadCallback(transformCycleData(cycles));
                        google.charts.load("current", {packages:["corechart"]});
                        google.charts.setOnLoadCallback(transformCycleData(cycles));
                        //transformCycleData(cycles);
                        
                        
                        
                      }
                                         
                 });
            });
                          
            function transformCycleData(cycleData) 
            {
                console.log("my data"+cycleData);
            var headers = ['Task', 'Hours per Day'];
            var data = [headers];
            var arr2 = [];
            cycleData.map((data) => {
                console.log("new data",data);
                        arr2.push(
                            ["Task","Hours per Day"],
                            ["approved",data.approved],
                            ["declines",data.declines],
                            ["cancels",data.cancels],
                            ["chargebacks",data.chargebacks],
                            ["commission",data.commission]
                        );
                    });
                console.log(arr2[0]);
                var options = {
    title: 'Charges of subatomic particles',
    legend: { position: 'top', maxLines: 2 },
    colors: ['#5C3292', '#1A8763', '#871B47', '#999999'],
    interpolateNulls: false,
  };
                //var chart = new google.visualization.PieChart(document.getElementById('piechart'));
                //chart.draw(arr2[0], options);
            //return arr2;
            var chart = new google.visualization.Histogram(document.getElementById('piechart'));
            chart.draw(arr2[0], options);
        }*/
        $("#searchbtn").click(function () {
            var startDate = $("#startDate").val();
            var endDate = $("#endDate").val();
            var campaignId = $("#dropdownOptions").val();
            var username = localStorage.getItem('crmusername');
            var password = $("#crmpass").val();

            $.ajax({
                type: 'POST',
                url: '/fetchRetentionReport',
                data: {
                    username: username,
                    password: password,
                    startDate: startDate,
                    endDate: endDate,
                    campaignId: campaignId
                },
                success: function (crmresponse) {
                    $("#total_orders").html(crmresponse.message.Total.orders);
                        $("#total_expense").html(crmresponse.message.Total.expensesTotal);
                        $("#total_gross").html(crmresponse.message.Total.grossTotal);
                        $("#total_net").html(crmresponse.message.Total.netTotal);
                        console.log(crmresponse);
                    var cycles = crmresponse.message.Total.cycles;
                    console.log("All the cycles",cycles);
                    google.charts.load("current", { packages: ["corechart"] });
                    google.charts.setOnLoadCallback(function () {
                        transformCycleData(cycles);
                    });
                }
            });
});

                    function transformCycleData(cycleData) {
                        // Create a data table for the histogram
                        var data = new google.visualization.DataTable();
                        data.addColumn('string', 'Cycle');
                        data.addColumn('number', 'Approved');
                        //data.addColumn('number', 'declines');

                        // Populate the data table with cycle numbers and corresponding frequencies
                        var histogramData = [];
                        cycleData.forEach(function (cycle) {
                            histogramData.push(['Cycle ' + cycle.cycleNumber, cycle.approved]);
                            //histogramData.push(['Cycle ' + cycle.cycleNumber, cycle.declines]);
                        });
                        data.addRows(histogramData);

                        // Set chart options
                        var options = {
                            title: 'Histogram of Approved Cycles',
                            legend: { position: 'none' },
                            width: 600,
                            height: 400
                        };

                        // Create a histogram chart and draw it
                        var chart = new google.visualization.Histogram(document.getElementById('piechart'));
                        chart.draw(data, options);
                    }

        

});
    
</script>


    </body>

</html>