<?php
global $wpdb, $table_prefix;
$status="";

//echo"<pre>";print_r($employees);
if($_SERVER['REQUEST_METHOD'] == "POST"){
  if(isset($_POST['delte-id']) && !empty($_POST['delte-id'])){
    $wpdb->delete($table_prefix."employee_management_system",array("id"=>intval($_POST['delte-id'])));
    $status = 1;
    $message ="Record deleted successfully";
  }
}
$employees =  $wpdb->get_results("SELECT * FROM ".$table_prefix."employee_management_system",ARRAY_A);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Employee List</title>

  <link rel="stylesheet" href="<?php echo EMS_PLUGIN_URL; ?>css/bootstrap.min.css">

  <link rel="stylesheet" type="text/css" href="<?php echo EMS_PLUGIN_URL; ?>css/dataTables.bootstrap4.min.css">
</head>
<body>
  <div class="container mt-5">
    <h2 style="background-color: #007bff; color: white; padding: 10px;">Employee List</h2>
    <table id="employeeTable" class="table table-striped table-bordered">
    <?php if($status == 1){?>
            <div class="alert alert-success">
                <?php echo $message; ?>
                </div>
            <?php }  ?>
      <thead>
        <tr>
          <th>ID</th>
          <th>Name</th>
          <th>Email</th>
          <th>Phone Number</th>
          <th>Designation</th>
          <th>Address</th>
          <th>Gender</th>
          <th>#Action</th>
        </tr>
      </thead>
      <tbody>
        <?php if(count($employees)> 0){

        foreach($employees as $employee){ ?>
      
        <tr>
          <td><?php echo $employee['id']; ?></td>
          <td><?php echo $employee['name']; ?></td>
          <td><?php echo $employee['email']; ?></td>
          <td><?php echo $employee['phone']; ?></td>
          <td><?php echo $employee['designation']; ?></td>
          <td><?php echo $employee['address']; ?></td>
          <td><?php echo ucfirst($employee['gender']); ?></td>
          <td>
            <div class="btn-group" role="group">
              <a href="admin.php?page=employee-management&action=edit&empId=<?php echo $employee['id']; ?>" class="btn btn-warning">Edit</a>&nbsp;
              <form id="frm-id-<?php echo $employee['id'] ?>" method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>?page=list-employee-management">
              <input type="hidden" name="delte-id" value="<?php echo $employee['id']; ?>">
            </form>
              <a href="javascript:void(0);" onclick="if(confirm('Are you sure you want to delete')){
                jQuery('#frm-id-<?php echo $employee['id'] ?>').submit(); }"
             class="btn btn-danger">Delete</a>&nbsp;
              <a href="admin.php?page=employee-management&action=view&empId=<?php echo $employee['id']; ?>" class="btn btn-info">View</a>
            </div>
          </td>
        </tr>
        <?php } }else{ ?>
          <tr> No data Found </tr>
          <?php } ?>
      </tbody>
    </table>
  </div>

  <!-- Bootstrap JS -->
  <script src="<?php echo EMS_PLUGIN_URL; ?>js/jquery-3.5.1.slim.min.js"></script>
  <script src="<?php echo EMS_PLUGIN_URL; ?>js/jquery.dataTables.min.js"></script>
  <script src="<?php echo EMS_PLUGIN_URL; ?>js/dataTables.bootstrap4.min.js"></script>
  <script>
    $(document).ready(function() {
      $('#employeeTable').DataTable();
    });
  </script>

