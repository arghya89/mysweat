<div>
    <img src="https://images.pexels.com/photos/18258096/pexels-photo-18258096/free-photo-of-scenic-photo-of-a-canal-in-venice-italy.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1">
    <img src="https://images.pexels.com/photos/18258096/pexels-photo-18258096/free-photo-of-scenic-photo-of-a-canal-in-venice-italy.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1">
    <img src="https://images.pexels.com/photos/18258096/pexels-photo-18258096/free-photo-of-scenic-photo-of-a-canal-in-venice-italy.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1">
</div>