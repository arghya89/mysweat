<?php
class studentmanagement {
    public function __construct(){
        add_action('admin_menu',array($this,'add_admin_menus'));
       
    }
    private $displaymessage ="";
    private $displaystatus="";
    private $action = "";
        public function add_admin_menus(){
        add_menu_page('Student System','Student System','manage_options','student-system','','dashicons-admin-multisite',18);
        //add_submenu_page('parent-slug','page title','menu Student','permission/compatibility','menu slug','');
        add_submenu_page('student-system','List Students','List Students','manage_options','student-system',array($this,'listStudentCallback'));
        add_submenu_page('student-system','Add Student','Add Student','manage_options','add-student',array($this,'addStudentCallback'));
       
    }
    public function listStudentCallback(){
        global $wpdb, $table_prefix;
        if(isset($_GET['action'])&&($_GET['action']=='edit')){
            
            $this->action = "edit";
            $action = $this->action;
            $studentId = $_GET['studentId'];
           $student = $this->get_studentdata($studentId);
          
            if (isset($_POST['studentId']) && $_SERVER['REQUEST_METHOD'] = "POST" && isset($_POST['from_btn_submit'])) {    //update existing data 
                echo $updatedId =$_POST['studentId'];
                //echo "<pre>";print_r($_POST);die();
                $wpdb->update($table_prefix.'student_system',array(
                    'name'=>$_POST['name'],
                    'email'=>$_POST['email'],
                    'phone'=>$_POST['phone'],
                    "gender"=>$_POST['gender']
                ),array('id'=>$studentId));
                
                  $this->displaystatus = 1;
                  $this->displaymessage="Student updated successfully";
                //   $message = $this->displaymessage;
                //   $status =  $this->displaystatus;
            } 
            $status = $this->displaystatus;
            $message = $this->displaymessage;
            include_once(SMS_PLUGIN_PATH."/pages/add-student.php");              
                
        }else if(isset($_GET['action'])&&($_GET['action']=='view')){
          
            $this->action = "view";
            $action = $this->action;
            $studentId = $_GET['studentId'];
           $student = $this->get_studentdata($studentId);
          include_once(SMS_PLUGIN_PATH."/pages/add-student.php");   
        }else{
          
        //echo"<pre>";print_r($students);
        if($_SERVER['REQUEST_METHOD'] == "POST"){
        if(isset($_POST['delte-id']) && !empty($_POST['delte-id'])){
         $wpdb->delete($table_prefix."student_system",array("id"=>intval($_POST['delte-id'])));
         $status = 1;
        $message ="Record deleted successfully";
        }
        }
        $students =  $wpdb->get_results("SELECT * FROM ".$table_prefix."student_system",ARRAY_A);
       
        include_once(SMS_PLUGIN_PATH."/pages/list-student.php");
    }
    }
    public function get_studentdata($studentId){
        global $wpdb, $table_prefix;
        $student = $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM ".$table_prefix."student_system WHERE id= %d", $studentId),ARRAY_A);
            return $student;
    }
    public function addStudentCallback(){
       
        if($_SERVER['REQUEST_METHOD'] == "POST" && isset($_POST['from_btn_submit'])){
        $this->SaveStudentdata();
        }

        $message = $this->displaymessage;
        $status  = $this->displaystatus;
        include_once(SMS_PLUGIN_PATH."/pages/add-student.php");
    }

    public function SaveStudentdata(){
        global $wpdb,$table_prefix;
            $name = sanitize_text_field($_POST['name']);
            $email = sanitize_text_field($_POST['email']);
            $phone = sanitize_text_field($_POST['phone']);
            $gender = sanitize_text_field($_POST['gender']);
            $wpdb->insert($table_prefix.'student_system',array(
                        'name'=>$name,
                        'email'=>$email,
                        'phone'=>$phone,
                        "gender"=>$gender
                    ));
                    $last_insert_id = $wpdb->insert_id;
                    if($last_insert_id >0){
                       $this->displaystatus = 1;
                        $this->displaymessage ="Student inserted successfully";
                    }else{
                        $this->status = 0;
                        $this->message ="Failed to insert data";
                    }
            
            // if (isset($_POST['studentId']) && $_POST['studentId'] != "") {    //update existing data 
            //   $updatedId =$_POST['studentId'];
            //     $wpdb->update($table_prefix.'student_system',array(
            //         'name'=>$name,
            //         'email'=>$email,
            //         'phone'=>$phone,
            //         "gender"=>$gender
            //     ),array('id'=>$updatedId));
                
            //     $this->displaystatus = 1;
            //        $this->displaymessage ="Student updated successfully";
            // }else{
            // // insert data to database
            //     $wpdb->insert($table_prefix.'student_system',array(
            //         'name'=>$name,
            //         'email'=>$email,
            //         'phone'=>$phone,
            //         "gender"=>$gender
            //     ));
            //     $last_insert_id = $wpdb->insert_id;
            //     if($last_insert_id >0){
            //        $this->displaystatus = 1;
            //         $this->displaymessage ="Student inserted successfully";
            //     }else{
            //         $this->status = 0;
            //         $this->message ="Failed to insert data";
            //     }
            // }
            
    }
    public function create_student_system(){
        global $wpdb, $table_prefix;
        $table_name =  $table_prefix."student_system";
        $create_table_sql = "CREATE TABLE IF NOT EXISTS {$table_name} (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `name` varchar(255) NOT NULL,
            `email` varchar(255) NOT NULL,
            `gender` varchar(5) NOT NULL,
            `phone` varchar(255) NOT NULL,
            `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
            PRIMARY KEY (`id`)
          ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
           include_once(ABSPATH . 'wp-admin/includes/upgrade.php');
           dbDelta($create_table_sql);
    }
    public function truncate_table_upon_deactivation(){
        global $wpdb,$table_prefix;
        $table = $table_prefix."student_system";
        $truncate_sql = "TRUNCATE `$table`";
        include_once(ABSPATH . 'wp-admin/includes/upgrade.php');
           dbDelta($truncate_sql);
    }
}