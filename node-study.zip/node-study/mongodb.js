const {MongoClient} = require('mongodb');
const url= "mongodb+srv://arghyammukherjee:arghyammukherjee@leaning-purpose.qdaigp8.mongodb.net/?retryWrites=true&w=majority&appName=leaning-purpose";
//mongoose.connect("mongodb+srv://arghyammukherjee:arghyammukherjee@leaning-purpose.qdaigp8.mongodb.net/?retryWrites=true&w=majority&appName=leaning-purpose");
const database = "test";
const client = new MongoClient(url);

/* there are 3 different types of pattern to connect the db and fetch the data from db **********/

/****************** FIRST WAY uncomment the the collection response inside the dbconnect method */
async function dbconnect()
{
let connection = await client.connect();
let db = connection.db(database);
return db.collection('users');
}
 module.exports = dbconnect;