<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;
use Illuminate\Support\Facades\DB;


class CampaignDetails extends Model
{

    use HasFactory;
    use HasApiTokens, HasFactory, Notifiable;
     protected $table = 'campaigndetails';
    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'campaign_id',
        'campaign_name',
        'is_active',
        'is_prepaid_blocked',
        'created_at',
        'time_zone',
    
    ];

    public static function insertCampaigns($data)
    {
        self::insert($data);
    }

    public function getAlltheCamaigninfo($adminid)
    {
        $query = "SELECT * FROM `campaigndetails` where `user_id`=".$adminid." ORDER by `campaign_id` ASC";
       

        $results = DB::select($query);

        return $results;
    }

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
    // protected $hidden = [
    //     'password',
    //     'remember_token',
    // ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    // protected $casts = [
    //     'email_verified_at' => 'datetime',
    // ];
}
