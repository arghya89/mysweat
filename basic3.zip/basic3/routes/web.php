<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\Admin\AdminController;
use App\Http\Controllers\Admin\StickyController;
use App\Http\Controllers\Admin\KonnektiveController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/login', [AuthController::class, 'index'])->name('login');
Route::post('/login', [AuthController::class, 'userLogin'])->name('userLogin');
Route::get('/registration', [AuthController::class, 'reagister'])->name('registration');
Route::post('/registration', [AuthController::class, 'createuser'])->name('register');
Route::get('/userdashboard', [AuthController::class, 'userdashboard'])->name('userdashboard');
Route::get('/logout',[AdminController::class,'logout'])->name('admin.logout');

Route::get('/userProfile',[AdminController::class,'profile'])->name('admin.userProfile');
Route::post('/storeprofile',[AdminController::class,'store_profile'])->name('admin.storeProfile');
Route::get('/campaignInfo',[AdminController::class,'showAlltheCampaigns'])->name('admin.showAlltheCampaigns');
Route::get('/listedcrm',[AdminController::class,'listedcrm'])->name('admin.listedcrm');
Route::get('/crm',[AdminController::class,'crm'])->name('admin.crm');
Route::post('/crm',[AdminController::class,'storeCRM'])->name('admin.storeCRM');


Route::get('/fetchcampaign',[StickyController::class,'fetchCampaigns'])->name('fetchcampaign');
Route::get('/showOrders/{id}',[AdminController::class,'fetchOrders'])->name('admin.fetchOrders');

Route::post('/check-konnektive-credentials', [KonnektiveController::class, 'checkCredentials']);
//the name should be different If we want to make it dynamic & in order to check the credentials of crm we need to add dropdown in view page

Route::get('/getordersFromKNK', [KonnektiveController::class,'orderFetchFromKonnetiveCRM'])->name('getordersFromKNK');
Route::get('/orderfromCRM/{selctedCRM}',[KonnektiveController::class,'orderfromCRM'])->name('orderfromCRM');
//Route::post('/fetchingcampaigns', [KonnektiveController::class,'fetchKonnektive_campaigns']);
Route::post('/campaignsdetails', [KonnektiveController::class,'fetchKonnecktivecampaigns']);
Route::post('/fetchRetentionReport', [KonnektiveController::class,'fetchRetentionReport']);
Route::post('/fetchgraphReport', [KonnektiveController::class,'fetchgraphReport']);





