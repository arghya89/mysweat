jQuery(document).ready(function($) {
      $('#employeeTable').DataTable();
    });

