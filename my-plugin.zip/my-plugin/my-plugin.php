<?php
/* 
Plugin Name: My Plugin
description: Testing purpose
Version :1.0
Author: Arghya Mukherjee
*/
if(!defined('ABSPATH')){ 
    die('Unauthorized access');
}
function myfunction_for_activation(){
    // create an table while activation the plugin
    global $wpdb,$table_prefix;
    $table = $table_prefix."employee";
    
    
    $sql_query ="CREATE TABLE IF NOT EXISTS `$table` (`id` INT NOT NULL AUTO_INCREMENT , `name` VARCHAR(255) NOT NULL , `email` VARCHAR(255) NOT NULL , `status` TINYINT NOT NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB;";
    $wpdb->query($sql_query); // install the table while activation

    // in ORDER to inset some dummy data while activation you can run the below code
    $dummy_data = array('name'=>'arghya',
    'email'=>'arghya.mukherjee@codeclouds.in',
    'status'=>'1');
    $wpdb->insert($table,$dummy_data);
    }
register_activation_hook(__FILE__,'myfunction_for_activation');

function myfunction_for_deactivation(){
    global $wpdb,$table_prefix;
    $table = $table_prefix."employee";
    
    
    //$sql_query ="DROP TABLE `$table`";
    $sql_query ="TRUNCATE `$table`";// truncate the table while deactivation
    $wpdb->query($sql_query);
}
register_deactivation_hook(__FILE__,'myfunction_for_deactivation');

function my_shortcode_function($atts){
 //var_dump($atts);
    $atts = array_change_key_case((array) $atts, CASE_LOWER);
    $atts= shortcode_atts(array(
        'type'=>'gallery'
    ),$atts);
    //return "Result: ".$atts['msg']." ".$atts['note'];
    //include 'gallery.php';
    include $atts['type'].".php";
    //return $args;
}
add_shortcode('my_shortcode_argument','my_shortcode_function');