<?php

/*
Plugin Name: Our first plugin
Description: Test plugin
version: 1.0
Author: Arghya
*/
add_filter('the_content', 'adendofcontent');
function adendofcontent($content){
    if(is_single() && is_main_query()){
        return $content." <strong>Arghya</strong>";
    }

    return $content;
   
}
add_filter('the_title','addontitle');
function addontitle($title){
    return $title." my heading";
}
?>