<style>
    #sms-add-student label.error{
        color:red;
        font-weight:500;
    }
  </style>
  <div class="container mt-5">
    <div class="card  col-sm-8" style="background:#f8f8f9">
      <div class="card-header" style="background:#5be982">
     <?php  if( isset($action)&&($action =="view")){  ?>
        <h2 class="mb-0">View Student</h2>
        <?php } else if( isset($action)&&($action =="edit")) { ?>
            <h2 class="mb-0">Edit Student</h2>
          <?php } else{ ?>
            <h2 class="mb-0">Add Student</h2>
          <?php }  ?>
      </div>
      <div class="card-body">
        <img src="<?php echo SMS_PLUGIN_URL; ?>images/default.png" style="width:100px">
        <?php if(!empty($status)&&($status == 1)){?>
            <div class="alert alert-success">
                <?php echo $message; ?>
                </div>
            <?php }else if(!empty($status)&&($status == 0)) { ?>
                <div class="alert alert-danger">
                <?php echo $message; ?>
                </div>
            <?php } ?>
        <form action="<?php if (isset($action)&&($action =="edit")){ echo 'admin.php?page=student-system&action=edit&studentId='.$student['id']; } else { echo $_SERVER['PHP_SELF']; ?>?page=add-student<?php } ?>" method="post" id="sms-add-student">
          <div class="form-group">
            <?php if(isset($action)&&($action =="edit")){ ?>
            <input type="hidden" name="studentId" value="<?php echo $student['id']; ?>">    
            <?php } ?>
            <label for="name">Name</label>
            <input name="name" type="text" class="form-control" id="name" placeholder="Enter name" value="<?php if(isset($_GET['studentId']) && isset($_GET['action'])&& isset($student)) { echo ucwords($student['name']);} ?>" required <?php if(isset($action)&&($action =="view")){ echo "readonly = 'readonly'";} ?>>
          </div>
          <div class="form-group">
            <label for="email">Email</label>
            <input name="email" type="email" class="form-control" id="email" placeholder="Enter email" value="<?php if(isset($_GET['studentId']) && isset($_GET['action'])&& isset($student)) { echo $student['email'];} ?>" required <?php if(isset($action)&&($action =="view")){ echo "readonly = 'readonly'";} ?>>
          </div>
         <div class="form-group">
            <label for="phone">Phone Number</label>
            <input name="phone" type="text" class="form-control" id="phone" placeholder="Enter phone number" value="<?php if(isset($_GET['studentId']) && isset($_GET['action'])&& isset($student)) { echo $student['phone'];} ?>" required <?php if(isset($action)&&($action =="view")){ echo "readonly = 'readonly'";} ?>>
          </div>
         <div class="form-group">
            <label for="email">Gender</label>
            <select name="gender" id="gender" class="form-control" required <?php if(isset($action)&&($action =="view")){ echo "disabled";} ?>>
            <option value="">Select Gender</option>
                <option value="male" <?php if(isset($student)&&(isset($_GET['studentId'])&&($student['gender'] =='male'))) {echo "selected";} ?>>Male</option>
                <option value="female" <?php if(isset($student)&&(isset($_GET['studentId'])&&($student['gender'] =='female'))) {echo "selected";} ?>>Female</option>
                <option value="other" <?php if(isset($student)&&(isset($_GET['studentId'])&&($student['gender'] =='other'))) {echo "selected";} ?>>Other</option>
            </select>
          </div>
          <div class ="form-group">
            <input type="text" id="profile_url" class="form-control" style="margin-bottom:5px;" name="profile_url" readonly>
            <button id="upload_profile_btn" class="btn btn-primary" type="button">Upload profile Image</button>
          </div>
          <?php  if(isset($action)&&($action =="view")){ ?>
            View Student
          <?php } else if(isset($action)&&($action =="edit")) { ?>
            <button type="submit" class="btn btn-primary" name="from_btn_submit">Update</button>
           <?php }else {  ?>
            <button type="submit" class="btn btn-primary" name="from_btn_submit">Submit</button>
            <?php } ?>
        </form>
      </div>
    </div>
  </div>

  <?php //wp_enqueue_media(); ?>
  <!--Bootstrap JS 
   <script src="<?php echo SMS_PLUGIN_URL; ?>js/jquery-3.5.1.slim.min.js"></script>
  <script src="<?php echo SMS_PLUGIN_URL; ?>js/popper.min.js"></script>
  <script src="<?php echo SMS_PLUGIN_URL; ?>js/bootstrap.min.js"></script>
  <script src="<?php echo SMS_PLUGIN_URL; ?>js/jquery.validate.min.js"></script>-->

  <script>
	/*$().ready(function() {
		$("#sms-add-student").validate({
			rules: {
				name: {
					required: true,
					minlength: 2
				},
				email: {
					required: true,
					email: true
				},
				address: {
					required: true,
					minlength: 2
				},
                phone: {
					required: true,
					minlength: 10
				},
				designation: {
					required: true,
					minlength: 2
				},
                gender: "required",
			},
			messages: {
				name: {
					required: "Please enter a name",
					minlength: "please enter a valid name"
				},
				email: "Please enter a valid email address",
                
                phone: {
					required: "Please enter  phone number",
					minlength: "please enter a valid phone number"
				},
                
				gender: "Please select gender"
			}
		});
    });*/
    
        </script>
        <script>
   /* jQuery("#upload_profile_btn").click(function(event){
    event.preventDefault(); 
    
    let mediauploader = wp.media({ 
        title: "Select profile image",
        multiple: false
    });
    
    mediauploader.on('select', function(){
        let attachment = mediauploader.state().get('selection').first().toJSON();
        console.log(attachment);
    });
    
    mediauploader.open();
});
*/
            </script>
</body>
</html>