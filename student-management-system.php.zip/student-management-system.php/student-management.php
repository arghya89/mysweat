<?php
/* plugin name: Student Management System
*description: This is Student Management system plugin 
*plugin URI: https://test.com
*Author:Arghya Mukherjee
*author URI: https://test.com
*version:1.0
*/
define("SMS_PLUGIN_PATH",plugin_dir_path(__FILE__)); // plugin path
define('SMS_PLUGIN_URL',plugin_dir_url(__FILE__));// plugin url
include_once(SMS_PLUGIN_PATH.'class/studentmanagement.php');
$studentmanagement_obj =  new studentmanagement();
register_activation_hook(__FILE__,array($studentmanagement_obj,'create_student_system'));
register_deactivation_hook(__FILE__,array($studentmanagement_obj,'truncate_table_upon_deactivation'));

add_action('admin_enqueue_scripts', 'sms_scripts');

function sms_scripts() {
    // Enqueue jQuery
    wp_enqueue_script('jquery');

    // Enqueue your other scripts
    wp_enqueue_style('sms-bootsrap.min', SMS_PLUGIN_URL.'css/bootstrap.min.css', array(), '1.0.0', 'all');
    wp_enqueue_style('sms-dataTables4', SMS_PLUGIN_URL.'css/dataTables.bootstrap4.min.css', array(), '1.0.0', 'all');

    //wp_enqueue_script('sms-slim.min', SMS_PLUGIN_URL.'js/jquery-3.5.1.slim.min.js', array(), '1.0.0');
    wp_enqueue_script('sms-proper', SMS_PLUGIN_URL.'js/popper.min.js', array('jquery'), '1.0.0');
    wp_enqueue_script('sms-bootstrap', SMS_PLUGIN_URL.'js/bootstrap.min.js', array('sms-proper'), '1.0.0');
    wp_enqueue_script('sms-validate', SMS_PLUGIN_URL.'js/jquery.validate.min.js', array('jquery'), '1.0.0');
    wp_enqueue_media();
    wp_enqueue_script('sms-dataTables', SMS_PLUGIN_URL.'js/jquery.dataTables.min.js', array(), '1.0.0');
    wp_enqueue_script('sms-dataTablesbootstrap', SMS_PLUGIN_URL.'js/dataTables.bootstrap4.min.js', array(), '1.0.0');
    wp_enqueue_script('sms-custom', SMS_PLUGIN_URL.'js/custom.js', array('jquery'), '1.0.0');
}

// function enqueue_sms_scripts() {
//     // Enqueue Bootstrap and jQuery Validate scripts
//     wp_enqueue_script('sms-slim.min', SMS_PLUGIN_URL.'js/jquery-3.5.1.slim.min.js', array(), '1.0.0');
//     wp_enqueue_script('sms-proper', SMS_PLUGIN_URL.'js/popper.min.js', array(), '1.0.0');
//     wp_enqueue_script('sms-bootstrap', SMS_PLUGIN_URL.'js/bootstrap.min.js', array('sms-proper'), '1.0.0');
//     wp_enqueue_script('sms-validate', SMS_PLUGIN_URL.'js/jquery.validate.min.js', array('jquery'), '1.0.0');

//     // Enqueue media scripts
//     wp_enqueue_media();

//     // Enqueue other scripts
//     wp_enqueue_script('sms-dataTables', SMS_PLUGIN_URL.'js/jquery.dataTables.min.js', array(), '1.0.0');
//     wp_enqueue_script('sms-dataTablesbootstrap', SMS_PLUGIN_URL.'js/dataTables.bootstrap4.min.js', array(), '1.0.0');
//     wp_enqueue_script('sms-custom', SMS_PLUGIN_URL.'js/custom.js', array('jquery'), '1.0.0');
// }

// add_action('admin_enqueue_scripts', 'enqueue_sms_scripts');
// function load_my_wp_media() {
//     wp_enqueue_media();
//  }
//  add_action( 'admin_enqueue_scripts', 'load_my_wp_media' );