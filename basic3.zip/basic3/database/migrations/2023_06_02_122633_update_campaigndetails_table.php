<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        DB::statement('
                CREATE TABLE campaigndetails (
                    -- Define your table columns here
                    campaign_id INT,
                    campaign_name VARCHAR(255),
                    is_active TINYINT,
                    is_prepaid_blocked TINYINT,
                    created_at TIMESTAMP,
                    time_zone VARCHAR(255)
                )
            ');
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
};
