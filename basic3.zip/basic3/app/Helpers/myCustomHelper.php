<?php
namespace App\Helpers;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use App\Models\crms;

class myUniqueCustomHelper
{

    public static function getTheSelectedCRM()
    {
        $loginuser_id= Auth::user()->id;
        //$crmData = crms::where('user_id',$loginuser_id)->first();/*************** in Eloquant query*/
        $query = 'SELECT * FROM `crms` WHERE `user_id` ='.$loginuser_id;
        $crmData = DB::select($query);
        $credentials = [];
            foreach ($crmData as $key=>$crm) {
                $credentials[] = [
                    'username' => $crm->username,
                    'password' => $crm->password,
                    'url' => $crm->url
                ];
            }
            return $credentials;
    }

    // public static function StickyFetchAllordersfrmCampign($campaignId,$crmApiUsername,$crmApiPassword,$url)
    // { //echo "h1";
    //     //echo $campaignId;
    //     $startdate="01/01/2022";
    //     $apiUsername = $crmApiUsername;
    //     $apiPassword = $crmApiPassword;
    //     //echo $apiEndpoint = $url."/api/v2/orders";
    //     $apiEndpoint = 'https://sandboxdemo.sticky.io/api/v2/order_view';
    //     //$apiEndpoint = 'https://api.stickycrm.com/v2/orders';

    //     // Set up authentication credentials
    //     $authCredentials = base64_encode("$apiUsername:$apiPassword");
    //     $headers = [
    //         'Authorization' => "Basic $authCredentials",
    //         'Content-Type' => 'application/json',
    //     ];
    
    //     // Set the query parameters
    //     $queryParams = [
    //         'method'    => 'order_find',
    //         'campaign_id' => $campaignId,
    //         'start_date' =>$startdate,
    //         'end_date' => '06/14/2023',
    //         'search_type'=>'any',
    //         'return_type'=>'order_view',
    //     ];
    
    //     // Make the GET request to fetch the orders
    //     $response = Http::withHeaders($headers)->get($apiEndpoint, $queryParams);
    
    //     // Check if the request was successful (status code 200)
    //     if ($response->ok()) {
    //         $orders = $response->json();
    //         return $orders;
    //     } else {
    //         echo "Error: {$response->status()} - {$response->body()}";
    //         return null;
    //     }
    // }
    public static function getOrderDetails($campaignId,$apiUsername,$apiPassword)
    {
        // Replace these values with your actual API username, password, and API endpoint
        $apiUsername = 'dev_test_api';
        $apiPassword = 'UjHn5XFJYQu4Q';
        $apiEndpoint = 'https://sandboxdemo.sticky.io/api/v2/campaigns/'.$campaignId.'/orders';
    
        // Set up authentication credentials
        $authCredentials = base64_encode("$apiUsername:$apiPassword");
        $headers = [
            'Authorization' => "Basic $authCredentials",
            'Content-Type' => 'application/json',
        ];
    
        // Make the initial GET request to fetch the first page
        //$response = Http::withHeaders($headers)->timeout(50)->get($apiEndpoint);
        $response = Http::withHeaders($headers)->timeout(50)->get($apiEndpoint, [
            'page' => 1,
            'per_page' => 30,
            'from' => '2023-04-10',
            'to' => '2023-04-21',
        ]);
    
        // if the request was successful (status code 200)
        dd($response);
        //echo "<pre>";print_r($response);die();
        if ($response->status() === 200) {
            die('here');
            $orders = response.json();
            $numOrders = count($orders);
    
            // If there are more than 30 orders, only return the first 30
            if ($numOrders > 30) {
                $orders = array_slice($orders, 0, 30);
            }
    
            return $orders;
        }else{
            return None; 
        }
    }
}
