const fs= require('fs');
const path= require('path');
const dirpath=path.join(__dirname,'files'); // get the folder path
//create 5 files inside the directory in a loop
// for(i=1;i<=5;i++){
//     fs.writeFileSync(dirpath+"/hello"+i+".txt","content inside the file");
// }
//show all the files list

fs.readdir(dirpath,(error,files)=>{
    console.log(files);
    files.forEach((file)=>{
        console.log("Files name is",file);
    })
})