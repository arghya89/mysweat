8<?php
/* 
Plugin Name: My Plugin2
description: Testing purpose creation
Version :1.0
Author: Arghya Mukherjee
*/
if(!defined('ABSPATH')){
    return "Unauthorized access";
}
function mynewfunction_for_activation(){
    // create an table while activation the plugin
    global $wpdb,$table_prefix;
    $table = $table_prefix."employee2";
    $sql_query ="CREATE TABLE IF NOT EXISTS `$table` (`id` INT NOT NULL AUTO_INCREMENT , `name` VARCHAR(255) NOT NULL , `email` VARCHAR(255) NOT NULL , `status` TINYINT NOT NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB;";
    $wpdb->query($sql_query);
}
register_activation_hook(__FILE__,'mynewfunction_for_activation');

function mynewfunction_for_deactivation(){
    global $wpdb,$table_prefix;
    $table = $table_prefix."employee2";
    $truncate_sql = "DROP TABLE ".$table;
    $wpdb->query($truncate_sql);
}
register_deactivation_hook(__FILE__,'mynewfunction_for_deactivation');
function mycustom_function(){
    $js_path = plugins_url('js/main.js',__FILE__,); // plugin path
    $style_path = plugins_url('css/style.css',__FILE__,); // plugin path

    $dependency = array('jquery'); //default jquery handeller of wordpress

    $version = filemtime(plugin_dir_path(__FILE__).'js/main.js');// directory path
    $style_version = filemtime(plugin_dir_path(__FILE__).'css/style.css');// directory path for style

    $is_login = is_user_logged_in() ? 1:0 ;
    wp_enqueue_script('my-custom-js',$js_path,$dependency,$version,true);
    wp_enqueue_style('my-custom-style',$style_path,'',$style_version,true);
    wp_add_inline_script('my-custom-js','var_is_login='.$is_login.';','before');
    
}
add_action('wp_enqueue_scripts','mycustom_function');
add_action('admin_enqueue_scripts','mycustom_function'); // to add the scripts in admin section

function my_callback_function(){
    global $wpdb,$table_prefix;
    $table = $table_prefix."employee2";
    $query = "SELECT * FROM ".$table;
    $results =  $wpdb->get_results($query);
    ob_start()?>
<table class="table table-striped">
  <thead class="thead-light">
    <tr>
      <th scope="col">ID</th>
      <th scope="col">Name</th>
      <th scope="col">Email</th>
      <th scope="col">Status</th>
    </tr>
  </thead>
  <tbody>
        <?php foreach ($results as $row): ?>
        <tr>
        <td scope="row"><?php echo $row->id; ?></td>
        <td><?php echo $row->name; ?></td>
        <td><?php echo $row->email; ?></td>
        <td><?php echo $row->status; ?></td>
        </tr>
        <?php endforeach ; ?>
    </tbody>

    </table>
    <?php 
    $html = ob_get_clean();
    return $html;
}

add_shortcode('my_shortcode','my_callback_function');
function callback_function_for_post(){
        $args = array('post_type'=>'post',
        'orderby'=>'ID',
        'order'=>'ASC',
);
    $query = new WP_Query($args);
    ob_start();
    if($query->have_posts()){ ?>
<ul>
<?php
while($query->have_posts()){
    $query->the_post();
    echo "<li><bold>".get_the_title()."</bold>==> ".get_the_content()."</li>";
}
?>
    </ul>
    <?php }
    wp_reset_postdata();
    $posts_html = ob_get_clean();
    return $posts_html;

}
add_shortcode('my_shortcode_for_post','callback_function_for_post');
