const app =require('./app');
const colors =require('colors');
console.log('Helloo'.red);
const http = require('http');
const { json } = require('stream/consumers');
const data =require('./apidata');
http.createServer((req,resp)=>{
    resp.writeHead(200,{"Content-Type":"application\json"});
    resp.write(JSON.stringify(data));
    //resp.write(JSON.stringify({name:'Arghya Mukherjee',email:'arghya.mukherjee@codeclouds.in'})); //for single data
    resp.end();
}).listen(4600);
// console.log(app.x);
// console.log(app.y);
// console.log(app);
// console.log(app.z());

// const arr = [1,2,3,4,5,6,7,8,3]
// let result = arr.filter((items)=>{
//     return items>2
// })
// console.log(result);
// let result1 = arr.filter((items)=>{
//     return items === 3
// })
// console.log(result1);

// let result2 = arr.filter((items)=>{
//     return items < 3
// })
// console.log(result2);
// const fs = require('fs');
// fs.writeFileSync('hello.txt','study node js')