<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;
use App\Models\crms;

use Carbon\Carbon;


class AuthController extends Controller
{
    public function index(){
        return view('auth.auth-login');
    }
    public function reagister(){
        return view('auth.register');
    }

    public function userLogin(Request $post){
        $validationdata= $post->validate([
            'email' => 'required',
            'password' => 'required',
        ],
        ['email.required'=>'Email is required',
        'password.required'=>'Password is required',
        ]);
        if(Auth::attempt($post->only('email','password'))){
            $notification = array(
                "message"=>"Profile  logged in successfully",
                "alert-type"=>"success"
            );
            return redirect('userdashboard')->with($notification);
        }
        return redirect('login')->withError('Credentials are not matched');
    }

    public function createuser(REQUEST $post){
        $validationdata= $post->validate([
            'name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'string', 'email', 'max:255', 'unique:'.User::class],
            'username' => ['required', 'string', 'max:255', 'unique:'.User::class],
            'password' => 'required',
            'confirmpassword'=>'required|same:password',
        ],
        [
            'name.required'=>'Name is required',
            'email.required'=>'Email is required',
            'username.required'=>'Username is required',
            'password.required'=>'Password is required',
            'confirmpassword.required'=>'Confirm password is required',
        ]);
        $user = User::create([
            'name' => $post->name,
            'email' => $post->email,
            'username' => $post->username,
            'password' => Hash::make($post->password), 
            'created_at'=>Carbon::now(),  
        ]);

        if(Auth::attempt($post->only('email','password'))){
            $notification = array(
                "message"=>"Profile created successfully",
                "alert-type"=>"success"
            );
            return redirect('userdashboard')->with($notification);
        }
        return redirect('register')->withError('Error');
    }
    public function userdashboard(){
        //return view('admin.dashboard');
        $adminid= Auth::user()->id; // get the current userid
        $model = new crms();
        $listedCRM = $model->getAllthelistedCRM($adminid);
        return view('admin.custom_dashboard',compact('listedCRM'));
    }
   
    // public function logout(){
    //     Session::flush();
    //     Auth::logout();
    //     $notification = array(
    //         "message"=>"Profile created successfully",
    //         "alert-type"=>"success");
    //     return redirect('login')->with($notification);

    // }
}
