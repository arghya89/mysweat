<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\CampaignDetails;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;


class StickyController extends Controller
{
    
    public function fetchCampaigns()
{
    // Replace these values with your actual API username, password, and API endpoint
    $apiUsername = 'dev_test_api';
    $apiPassword = 'UjHn5XFJYQu4Q';
    $apiEndpoint = 'https://sandboxdemo.sticky.io/api/v2/campaigns';

    // Set up authentication credentials
    $authCredentials = base64_encode("$apiUsername:$apiPassword");
    $headers = [
        'Authorization' => "Basic $authCredentials",
        'Content-Type' => 'application/json',
    ];

    // Make the initial GET request to fetch the first page
    $response = Http::withHeaders($headers)->get($apiEndpoint);

    // Check if the request was successful (status code 200)
    if ($response->ok()) {
        $responseData = $response->json();

        // Store the campaigns from the first page
        $this->storeCampaigns($responseData['data']);

        // Fetch remaining pages if available
        $currentPage = $responseData['current_page'];
        $lastPage = $responseData['last_page'];

        while ($currentPage < $lastPage) {
            $nextPageUrl = $responseData['next_page_url'];

            // Make a request to the next page
            $response = Http::withHeaders($headers)->get($nextPageUrl);

            if ($response->ok()) {
                $responseData = $response->json();

                // Store the campaigns from the current page
                $this->storeCampaigns($responseData['data']);

                $currentPage = $responseData['current_page'];
                $lastPage = $responseData['last_page'];
            } else {
                echo "Error: {$response->status()} - {$response->body()}";
                break;
            }
        }

        echo 'All campaigns stored in the database.';
    } else {
        echo "Error: {$response->status()} - {$response->body()}";
    }
}

    private function storeCampaigns($campaigns)
    {
        foreach ($campaigns as $campaign) {
            CampaignDetails::create([
                                'campaign_id' => $campaign['id'],
                                'campaign_name' => $campaign['name'],
                                'is_active' => $campaign['is_active'],
                                'is_prepaid_blocked' => $campaign['is_prepaid_blocked'],
                                'created_at' => $campaign['created_at']['date'],
                                'time_zone' => $campaign['created_at']['timezone']
            ]);
        }
    }
   

    // private function storeCampaigns($campaigns)
    // {
    //     CampaignDetails::chunk(100, function ($campaignsChunk) {
    //     $insertData = [];

    //     foreach ($campaignsChunk as $campaign) {
    //                 $insertData[] = [
    //                     'campaign_id' => $campaign['id'],
    //                     'campaign_name' => $campaign['name'],
    //                     'is_active' => $campaign['is_active'],
    //                     'is_prepaid_blocked' => $campaign['is_prepaid_blocked'],
    //                     'created_at' => $campaign['created_at']['date'],
    //                     'time_zone' => $campaign['created_at']['time_zone'],
    //                     'created_at' => now(),
    //                     'updated_at' => now(),
    //                 ];
    //         }

    //         CampaignDetails::insert($insertData); // inser method provided by laravel
    //        // CampaignDetails::insertCampaigns($insertData); you can insert all the data  by creating a function as well insertCampaigns in model as well

    //     });
    // }
}

