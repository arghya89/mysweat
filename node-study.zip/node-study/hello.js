//const mission = "learn";
const mission = process.argv[2];
if(mission === "learn"){
    console.log(`time to ${mission} Node`);
}else{
    console.log("Do more func with node");
}
