const dbconnect = require('./mongodb');
const insert =async ()=>{
    const  db  = await dbconnect();
    const result = await db.insertMany([
         {name:"MicroMax1",brand:"MicroMax",price:2500,category:"mobile"},
        {name:"MicroMax2",brand:"MicroMax",price:2500,category:"mobile"},
         {name:"MicroMax3",brand:"MicroMax",price:2500,category:"mobile"}
    ]);
    if(result.acknowledged){
        console.log("Inserted successfully");
    }
}
insert();