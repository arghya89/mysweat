module.exports ={x:20,y:30,
z:function(){ return "study node"}}