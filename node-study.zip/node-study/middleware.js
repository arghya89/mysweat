module.exports= reqfilter = (req,resp,next)=>{
    if(!req.query.age){
        resp.send('Please provide your age to access  page')
    }
    else if(req.query.age < 18){
    resp.send('Not eligibale to access  page')
    }
    else{
        next();
    }
}
