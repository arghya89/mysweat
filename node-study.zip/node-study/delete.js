const dbconnect = require('./mongodb');
const delterecord = async()=>{
    let db = await dbconnect();
    let result = await db.deleteOne({name:"Nokia 110"});
    console.log(result);

    // to delte a record***************************/
    /*if(result.acknowledged > 0){
        console.warn("data deleted successfully");
    }*/
    if(result.deletedCount == 0){ // suppose if we want to delete a record which is not present or alreday deleted
        console.warn("No data found or data alreday delted previously");

    }else if(result.acknowledged > 0){

        console.warn("data deleted successfully");
    }
}
delterecord();