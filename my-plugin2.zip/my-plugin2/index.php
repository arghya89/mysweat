<?php 
/* silence is golden */