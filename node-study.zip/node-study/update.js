const dbconnect = require('./mongodb');
const updaterecord = async () => {
    let db = await dbconnect();
    //let collection = db.collection('test'); // Replace 'your_collection_name' with your actual collection name
    /*let result = await db.updateOne(
        // single column update code
        // { name: "pixel" },
        // { $set: { name: "pixel pro" } }

        //multiple coumn update code
        { name: "MicroMax1" },
        { $set: { name: "MicroMax1 galaxy",price:'2800' } }

        

    );*/
    /********************** update multiple row based on single condition ***********/
    let result = await db.updateMany(
        { brand: "MicroMax India" },
        { $set: { brand: "MicroMax India Inc"} }

    );
    console.log(result);
    if(result.modifiedCount > 0){
        console.warn("all records updated successfully");
    }
   
}

updaterecord();