@extends('admin.admin-master')
@section('admin')
<div class="page-content">
                    <div class="container-fluid">

                        <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                                    <h4 class="mb-sm-0">Data Tables</h4>

                                    <div class="page-title-right">
                                        <ol class="breadcrumb m-0">
                                            <li class="breadcrumb-item"><a href="javascript: void(0);">Tables</a></li>
                                            <li class="breadcrumb-item active">CRM</li>
                                        </ol>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <!-- end page title -->
                        
                        <div class="row">
                            <div class="col-12">
                                <div class="card">
                                    <div class="card-body">
        
                                        <h4 class="card-title">Lited CRM</h4>
                                        <!-- <p class="card-title-desc">DataTables has most features enabled by
                                            default, so all you need to do to use it with your own tables is to call
                                            the construction function: <code>$().DataTable();</code>.
                                        </p> -->
                                        @empty($listedCRM)
                                                    CRM not added
                                       @else
                                        <table id="datatable" class="table table-bordered dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                                            <thead>
                                            <tr>
                                                <th>CRM Name</th>
                                                <th>User Name</th>
                                                <th>Password</th>
                                                <th>URL</th>
                                                <th>Status</th>
                                                
                                            </tr>
                                            </thead>
        

                                            <tbody>
                                                @foreach($listedCRM as $data)
                                                
                                            <tr>
                                                <td>{{ $data->crm_name }}</td>
                                                <td>{{ $data->username }}</td>
                                                <td>{{ $data->password }}</td>
                                                <td>{{ $data->url }}</td>
                                                <td> @if($data->status == 1) <span style ="font-weight:bold;color:green;">Active</span> @else <span style ="font-weight:bold;color:red;">Disabled </span> @endif</td>
                                                <td><a href="">Edit</a></td>
                                            </tr>
                                            @endforeach
                                            
                                            </tbody>
                                        </table>
                                        @endif
        
                                    </div>
                                </div>
                            </div> <!-- end col -->
                        </div> <!-- end row -->
        
                        
                        
                    </div> <!-- container-fluid -->
                </div>
                @endsection