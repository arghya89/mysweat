const { error } = require('console');
const fs= require('fs');
const path = require('path');
const dirpath = path.join(__dirname,'crud'); // get the folder path
const filepath = dirpath+"/crud.txt"; // set the filepath inside a variable
//fs.writeFileSync(filepath,'Test conent'); // create file inside thecrud directory andput some text

// fs.readFile(filepath,'utf-8',(error,item)=>{    // read the file content
//     console.log(item);
// });

// updae the content ofthe file
// fs.appendFile(filepath,' And this text we have updated by using node',(error)=>{
//     if(!error) console.log('file has been updated successfully');
// });

/******************rename the file ******************* */
fs.rename(filepath,`${dirpath}/crud-operation.txt`,(error)=>{
    if(!error) console.log('file rename successfully')
})
// delete file 
//fs.unlink(`${dirpath}/crud-operation.txt`);