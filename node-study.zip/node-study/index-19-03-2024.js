const express =  require('express');
const app = express();
app.get('',(req,res)=>{
    res.send('Welcome Home in express');
});
app.get('/about',(req,res)=>{
    res.send(`<input type="text" name="username" placeholder="Username" value="${req.query.name}">
    <input type="button" value="click Me">`);
});
app.get('/contact',(req,res)=>{
    res.send('Welcome Contact Page');
})
app.get('/help',(req,res)=>{
    res.send([
        {name: 'Codeclouds It solution',
    website: 'Codeclouds.com'},
    {
        plan1:'Starter Plan',
        plan2:'Part-time Plan',
        plan3:'Full-Time Plan'
    }
    ]);
})
app.listen('5000');